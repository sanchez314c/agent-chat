---
name: 🐛 Bug Report
about: Create a report to help us improve AgentCHAT
title: '[BUG] '
labels: bug, triage
assignees: ''

## 🐛 Bug Description
<!-- A clear and concise description of what the bug is. -->

## 🔧 Priority
- [ ] Critical - Application crashes or major features broken
- [ ] High - Feature not working as intended
- [ ] Medium - Annoying but workaround exists
- [ ] Low - Minor issue or cosmetic problem

## 🔄 To Reproduce
<!-- Steps to reproduce the behavior -->
1.
2.
3.
4.

## ✅ Expected Behavior
<!-- A clear and concise description of what you expected to happen. -->

## 📱 Platform Information
**Operating System:**
- [ ] macOS (Intel)
- [ ] macOS (Apple Silicon/ARM64)
- [ ] Windows (x64)
- [ ] Windows (x86)
- [ ] Linux (x64)
- [ ] Linux (ARM64)
- [ ] Linux (ARMv7)

**OS Version:** <!-- e.g., macOS 14.5, Windows 11 23H2, Ubuntu 22.04 -->

**AgentCHAT Version:** <!-- e.g., 1.0.0, 1.1.0-beta -->

**Installation Method:**
- [ ] Official DMG installer
- [ ] Official EXE installer
- [ ] AppImage (Linux)
- [ ] DEB package (Linux)
- [ ] Built from source
- [ ] Portable version
- [ ] Other:

## 🤖 AI Configuration
**AI Providers Used:** <!-- Select all that apply -->
- [ ] Anthropic Claude
- [ ] OpenAI GPT
- [ ] Google Gemini
- [ ] OpenRouter
- [ ] Local model (Ollama/LM Studio)
- [ ] Other:

**Models Configured:** <!-- e.g., Claude 3.5 Sonnet, GPT-4, Gemini 1.5 Pro -->

## 📸 Screenshots
<!-- If applicable, add screenshots to help explain your problem. -->

## 🔍 Console Errors
<!-- If you see any errors in the developer console, please include them here. -->

**To open developer tools:**
- **Windows/Linux:** `Ctrl + Shift + I`
- **macOS:** `Cmd + Option + I`

```javascript
// Paste console errors here
```

## 📋 Additional Context
<!-- Add any other context about the problem here. -->

## 🔧 Troubleshooting Steps Taken
<!-- Please describe what you've already tried to fix the issue. -->
1.
2.
3.

## 📁 Log Files (Optional)
<!-- If applicable, please attach relevant log files. -->

**Application Logs Location:**
- **macOS:** `~/Library/Logs/AgentCHAT/`
- **Windows:** `%APPDATA%/AgentCHAT/logs/`
- **Linux:** `~/.config/AgentCHAT/logs/`

**How to collect logs:**
1. Open the application folder
2. Navigate to the logs directory above
3. Zip the entire logs folder
4. Attach to this issue

## 🏷️ Labels Requested (Optional)
<!-- Suggest any labels that might help categorize this issue -->
- [ ] crash
- [ ] performance
- [ ] ui/ux
- [ ] api-issue
- [ ] build-issue
- [ ] documentation
- [ ] enhancement

## ✅ Checklist
- [ ] I have searched existing issues for similar problems
- [ ] I have provided all requested information
- [ ] I have included relevant screenshots and logs
- [ ] I have checked that this is not a duplicate issue