## 📋 Description

<!-- Brief description of the changes made in this pull request. -->

### 🏷️ Change Type
<!-- Select all that apply -->
- [ ] 🐛 Bug fix (non-breaking change that fixes an issue)
- [ ] ✨ New feature (non-breaking change that adds functionality)
- [ ] 💥 Breaking change (fix or feature that would cause existing functionality to not work as expected)
- [ ] 📝 Documentation update
- [ ] 🎨 Code style/formatting (linting, code formatting)
- [ ] ♻️ Code refactoring (improving code structure without changing functionality)
- [ ] ⚡ Performance improvements
- [ ] 🔧 Build/CI related changes
- [ ] 🔒 Security improvement
- [ ] 🤖 AI provider support
- [ ] 🖥️ Platform-specific changes
- [ ] 📦 Dependency updates

## 🎯 Purpose

Why is this change necessary? What problem does it solve?

## 🔄 Changes Made

List the specific changes made:

- **Feature 1**: Description of what was changed
- **Feature 2**: Description of what was changed
- **Fix**: Description of what was fixed

## 🧪 Testing

### How was this tested?
- [ ] Manual testing with the following scenarios:
  - Scenario 1: ...
  - Scenario 2: ...
- [ ] Automated tests added/updated
- [ ] Cross-platform testing (Windows, macOS, Linux)

### Test Environment
- **OS**: [e.g., macOS 14.0, Windows 11, Ubuntu 22.04]
- **Node.js Version**: [e.g., 18.17.0]
- **AgentCHAT Version**: [e.g., 1.0.1]

## 📸 Screenshots

If applicable, add screenshots to demonstrate the changes:

**Before:**
[Add screenshot before changes]

**After:**
[Add screenshot after changes]

## ✅ Pre-Merge Checklist

### Code Quality
- [ ] 📖 I have read the [CONTRIBUTING guide](../docs/CONTRIBUTING.md)
- [ ] 🔍 My code follows the coding style guidelines of this project
- [ ] 🧪 I have performed a self-review of my own code
- [ ] 🚫 My changes generate no new warnings (`npm run lint` passes)
- [ ] 🏗️ I have verified that the build still passes (`npm run build`)
- [ ] 📦 My changes do not break existing functionality

### Testing & Verification
- [ ] 🌐 I have tested on multiple platforms (if applicable)
  - [ ] macOS (Intel)
  - [ ] macOS (Apple Silicon)
  - [ ] Windows (x64)
  - [ ] Linux (x64)
- [ ] 🤖 AI provider functionality tested (if applicable)
- [ ] 📱 UI/UX changes verified in both light and dark themes (if applicable)
- [ ] 🔒 Security implications have been considered and addressed

### Documentation
- [ ] 📝 I have updated the documentation as necessary
  - [ ] README.md (if user-facing changes)
  - [ ] CLAUDE.md (if developer-facing changes)
  - [ ] DEVELOPMENT.md (if development workflow changes)
  - [ ] API documentation (if API changes)
  - [ ] CHANGELOG.md (for significant changes)
- [ ] 📸 I have added screenshots for UI changes (if applicable)

### Platform-Specific Considerations
- [ ] 🍎 macOS changes tested with proper code signing (if applicable)
- [ ] 🪟 Windows changes tested with installer (if applicable)
- [ ] 🐧 Linux changes tested with packaging (if applicable)
- [ ] 📦 Build process creates all expected packages

## 🔗 Related Issues

- Closes #[issue number]
- Related to #[issue number]
- Depends on #[issue number]

## 📊 Additional Notes

Any additional context, notes, or considerations that reviewers should be aware of.

---

## 📖 Reviewer Guidelines

### Areas to Focus On
- **Security**: Are there any security implications?
- **Performance**: Does this change impact performance?
- **User Experience**: How does this affect the user experience?
- **Code Quality**: Is the code clear, maintainable, and well-documented?
- **Testing**: Are the tests adequate and do they cover edge cases?

### Approval Criteria
- [ ] Code is well-written and follows project conventions
- [ ] Tests are comprehensive and pass
- [ ] Documentation is updated
- [ ] No breaking changes without proper justification
- [ ] Security implications have been considered
- [ ] Performance impact is acceptable