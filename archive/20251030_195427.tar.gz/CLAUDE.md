# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) and other AI assistants when working with code in this repository.

## Development Commands

### Primary Development Workflow
```bash
# Start development with hot reload (most common)
npm run electron:dev     # Vite dev server + Electron with hot reload

# Alternative development commands
npm run dev              # Vite dev server only (for web testing)
npm run electron         # Electron only (requires Vite server running separately)
```

### Build Commands
```bash
# Build application
npm run build            # TypeScript compilation + Vite build
npm run lint             # Run ESLint on TypeScript files

# Comprehensive builds (NEW)
./scripts/build-compile-dist.sh                    # All platforms, all variants
./scripts/build-compile-dist.sh --skip-bloat     # Faster without analysis
./scripts/build-release-run.sh                    # Current platform only

# Distribution builds
npm run dist             # Full production build for current platform
npm run dist:mac         # Build for macOS
npm run dist:win         # Build for Windows
npm run dist:linux       # Build for Linux
npm run dist:maximum     # Build for all platforms and architectures

# Unified build script (legacy)
./scripts/build-release-run.sh                    # Build and run for current platform
./scripts/build-release-run.sh --dev              # Development mode
./scripts/build-release-run.sh --platform [mac|win|linux|all]
./scripts/build-release-run.sh --build-only       # Build without running
./scripts/build-release-run.sh --clean            # Clean build
```

### Build Analysis and Maintenance
```bash
# Build optimization and analysis
./scripts/bloat-check.sh                         # Analyze build sizes and dependencies
./scripts/temp-cleanup.sh                        # Clean system temp files
```

## Architecture Overview

### Electron Application Structure
This is an **Electron desktop application** with clear separation between processes:

- **Main Process** (`src/main.cjs`): Node.js environment handling file system, storage, window management
- **Renderer Process** (`src/` React app): Chromium environment running the React frontend
- **Preload Script** (`src/preload.cjs`): Secure bridge between main and renderer processes
- **Build Output**: Vite builds React app to `dist/renderer`, Electron packages for distribution to `dist/`

### Key Architectural Patterns

**Secure Storage**: API keys encrypted using `electron-store` with per-installation encryption keys
```javascript
// Main process handles all secure storage operations
store = new Store({
  encryptionKey: getEncryptionKey(),
  name: 'agentchat-config'
})
```

**IPC Communication**: All main/renderer communication through secure IPC channels defined in preload script

**Agent Architecture**: Multi-agent conversation system with pluggable AI providers (Claude, GPT-4, Gemini, OpenRouter, and 13+ other providers)

### Multi-Provider AI Support

The application supports 15+ AI providers through a unified interface:
- **Major Providers**: Anthropic Claude, OpenAI GPT, Google Gemini, OpenRouter
- **Open Source**: Llama, Mixtral, Gemma, Mistral, and more via OpenRouter
- **Local Models**: Ollama, LM Studio, and other local servers
- **Specialized**: DeepSeek, Groq, HuggingFace, Meta, Pi, Together, xAI

## Project Structure

### Core Source Files
```
src/
├── components/              # React UI components
│   ├── AgentConfigPanel.tsx # Agent settings and configuration
│   ├── ConversationPanel.tsx # Main chat interface
│   ├── MessageBubble.tsx    # Individual message display
│   ├── StatusBar.tsx        # Bottom status bar
│   └── APIKeyModal.tsx      # Secure API key configuration
├── services/                # Business logic layer
│   ├── APIClient.ts         # AI provider API clients
│   └── AgentManager.ts      # Core agent orchestration
├── types/                   # TypeScript definitions
│   └── index.ts             # Core type definitions for providers, agents, messages
├── App.tsx                  # Main React application
├── main.tsx                 # React entry point
├── main.cjs                 # Electron main process
├── preload.cjs              # Secure IPC bridge
└── index.css               # Global styles
```

### Build and Distribution
```
dist/                        # All built applications and packages
├── *.dmg                    # macOS disk images (Intel, ARM64, Universal)
├── *.pkg                    # macOS installers
├── *.exe                    # Windows installers (NSIS)
├── *.msi                    # Windows installers (Microsoft)
├── *.AppImage               # Linux portable applications
├── *.deb                    # Debian/Ubuntu packages
├── *.rpm                    # Red Hat/Fedora packages
├── *.snap                   # Snap packages
├── *.tar.gz, *.tar.xz       # Linux archives
└── */unpacked/              # Raw application directories
```

### Build System Scripts
```
scripts/
├── build-compile-dist.sh    # NEW: Comprehensive all-platform build system
├── build-release-run.sh     # Unified build and run script
├── compile-build-dist.sh    # Production build with optimization
├── bloat-check.sh           # Build size and dependency analysis
└── temp-cleanup.sh          # System cleanup utilities
```

## Code Conventions

### TypeScript Configuration
- **Strict mode enabled** with ES2020 target
- **Path mapping**: `@/*` resolves to `./src/*`
- **JSX**: `react-jsx` transform
- All components must have proper TypeScript interfaces for props

### React Patterns
- **Functional components only** with hooks (useState, useEffect, useCallback, useRef)
- **Props destructuring** in component parameters
- **Custom hooks** for complex state logic
- React.StrictMode enabled in development

### File Naming Conventions
- **Components**: PascalCase (`AgentConfigPanel.tsx`)
- **Services**: PascalCase (`AgentManager.ts`)
- **Types**: PascalCase interfaces (`AgentConfig`, `ConversationState`)
- **Variables/Functions**: camelCase (`handleStartConversation`)
- **Constants**: UPPER_SNAKE_CASE (`API_PROVIDERS`)
- **Scripts**: kebab-case (`build-compile-dist.sh`)

### Styling Approach
- **Framework**: Tailwind CSS 3 with utility-first approach
- **Theme**: Dark mode primary (`bg-dark-900`, `text-gray-100`)
- **Icons**: Lucide React icon library
- **No CSS modules or styled-components** - pure Tailwind utilities

## AI Integration Architecture

### Provider Support
The application supports multiple AI providers through a unified interface:

#### Major Commercial Providers
- **Anthropic Claude**: Claude 3.5 Sonnet, Claude 3 Opus, Claude 3 Haiku
- **OpenAI**: GPT-4, GPT-4 Turbo, GPT-3.5 Turbo
- **Google Gemini**: Gemini 1.5 Pro, Gemini 1.5 Flash

#### Open Source via OpenRouter
- **Meta**: Llama 3.1, Llama 3, Llama 2
- **Mistral**: Mixtral, Mistral 7B
- **Google**: Gemma 2, Gemma
- **And many more** via OpenRouter's unified API

#### Local and Specialized Providers
- **Local**: Ollama, LM Studio, LlamaCPP
- **Specialized**: DeepSeek, Groq, HuggingFace, xAI, Together

### Agent Configuration Pattern
Each agent configured with:
- Provider selection and model variant
- System persona and behavior instructions
- Temperature, max tokens, and context window settings
- Advanced parameters (top_p, top_k, frequency_penalty, presence_penalty)
- Local server configuration for self-hosted models
- Secure API key storage with per-installation encryption

## Development Workflow

### File Organization Principles
- **Configuration files** in project root (vite.config.ts, tailwind.config.js, etc.)
- **Source code** in `src/` directory
- **Build assets** in `build-resources/`
- **Documentation** in `docs/` and project root
- **Scripts** in `scripts/` directory

### Build Process Flow
1. **TypeScript compilation** (`tsc`) - Type checking and validation
2. **Vite build** - Bundles React app with assets to `dist/renderer`
3. **Electron Builder** - Creates platform-specific installers to `dist/`
4. **Package generation** - Creates all supported package types (DMG, EXE, AppImage, etc.)

### Testing Development Changes
Always test both:
1. **Development mode**: `npm run electron:dev` (hot reload)
2. **Production build**: `npm run build && npm run electron:preview` (verify packaging)

### Common Development Tasks
- **Add new AI provider**: Extend `APIClient.ts` service and update provider types
- **UI modifications**: Edit React components in `src/components/`
- **Storage changes**: Modify main process handlers in `src/main.cjs`
- **IPC additions**: Update `src/preload.cjs` for new main/renderer communication
- **Build customization**: Modify `scripts/build-compile-dist.sh` for new build options

## Security Considerations

### Secure Architecture
- **Context isolation enabled** - renderer cannot access Node.js APIs
- **Sandboxed web content** - strict security boundaries
- **Encrypted storage** - API keys never stored in plain text
- **Secure IPC** - all main/renderer communication through preload script

### API Key Management
- **Per-installation encryption keys** - unique encryption for each installation
- **No API key logging** - keys never appear in logs or debug output
- **Memory protection** - keys cleared from memory when not in use
- **Platform-specific storage** - uses system secure storage where available

### Build Security
- **No source code in builds** - TypeScript compiled, source maps excluded
- **Dependency verification** - npm audit and security checks
- **Code signing** - macOS and Windows code signing for distribution

## Build System Details

### Comprehensive Build Script
The `build-compile-dist.sh` script provides:
- **All platform variants**: macOS (x64, ARM64, Universal), Windows (x64, x86, ARM64), Linux (x64, ARM64, ARMv7l)
- **All package types**: DMG, PKG, EXE, MSI, ZIP, AppImage, DEB, RPM, SNAP, TAR
- **Bloat analysis**: Automatic dependency and build size optimization
- **System cleanup**: Temporary file management and optimization
- **Error handling**: Comprehensive error checking and recovery

### Build Optimization
- **Maximum compression** - electron-builder compression settings
- **Parallel builds** - Multi-threaded building for faster compilation
- **Dependency analysis** - Automated duplicate detection and optimization
- **Size monitoring** - Real-time build size tracking and warnings

### Icon and Asset Management
- **Multi-platform icons**: Icons stored in `build-resources/icons/`
- **Automatic icon generation**: Electron Builder generates required icon sizes
- **Asset optimization**: Images and assets optimized for each platform
- **Consistent branding**: Unified icon set across all platforms

## Troubleshooting Common Issues

### Build Problems
- **Dependencies**: Run `npm install` and check for outdated packages
- **Node.js version**: Ensure Node.js 16+ is installed
- **Platform tools**: Install platform-specific build tools (Xcode, Visual Studio Build Tools)
- **Disk space**: Ensure sufficient storage for large builds

### Development Issues
- **Hot reload not working**: Check port conflicts and firewall settings
- **TypeScript errors**: Run `npx tsc --noEmit` to check for type errors
- **Import errors**: Verify path aliases and module resolution
- **CSS not loading**: Check Tailwind CSS configuration and build process

### Electron Issues
- **Blank screen**: Check console for errors and verify React app loads
- **IPC errors**: Ensure preload script properly exposes required APIs
- **Window issues**: Check window configuration and main process setup
- **Security errors**: Verify context isolation and security settings

## Performance Optimization

### Build Performance
- **Parallel builds**: Use maximum available CPU cores
- **Incremental builds**: Only rebuild changed components
- **Dependency caching**: Cache build dependencies for faster rebuilds
- **Build analysis**: Regular bloat checks to identify optimization opportunities

### Runtime Performance
- **Memory management**: Monitor and optimize memory usage
- **UI responsiveness**: Use React Developer Tools for performance profiling
- **Network optimization**: Efficient API calls and response handling
- **Asset loading**: Optimize image and asset sizes

## Deployment and Distribution

### Release Process
1. **Version bump**: Update version in package.json
2. **Comprehensive build**: Run `./scripts/build-compile-dist.sh`
3. **Quality checks**: Verify builds on target platforms
4. **Code signing**: Sign applications for distribution
5. **Release**: Publish to distribution channels

### Distribution Channels
- **GitHub Releases**: Primary distribution channel
- **Auto-update**: Built-in update mechanism for seamless updates
- **Platform stores**: App Store, Microsoft Store (optional)
- **Direct downloads**: Website and documentation links

### Platform-Specific Notes
- **macOS**: Code signing required for distribution; notarization for App Store
- **Windows**: Code signing recommended; SmartScreen warnings without signing
- **Linux**: Package repositories and AppImage for universal distribution

This file should be updated as the project evolves and new patterns emerge.