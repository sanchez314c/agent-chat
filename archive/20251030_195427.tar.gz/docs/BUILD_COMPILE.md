# Build & Compile Instructions

## Overview

This document provides comprehensive instructions for building and compiling the AgentCHAT application across all supported platforms.

## Prerequisites

- Node.js 18+
- npm or yarn
- Git

## Development Build

```bash
# Install dependencies
npm install

# Start development server with hot reload
npm run dev

# Build for development
npm run build:dev
```

## Production Build

```bash
# Build for all platforms
npm run build

# Build for specific platforms
npm run build:mac    # macOS
npm run build:win    # Windows
npm run build:linux  # Linux
```

## Build Configuration

Build settings are configured in:

- `package.json` - Build scripts and dependencies
- `electron-builder.config.js` - Platform-specific build options
- `vite.config.js` - Build tool configuration

## Build Outputs

Production builds are created in the `dist/` directory:

- **macOS**: `.dmg` installer
- **Windows**: `.exe` installer
- **Linux**: `.AppImage`, `.deb`, `.rpm` packages

## Troubleshooting

See [TROUBLESHOOTING.md](TROUBLESHOOTING.md) for common build issues and solutions.