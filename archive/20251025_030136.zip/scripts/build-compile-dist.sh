#!/bin/bash
# build-compile-dist.sh - Master build script for AgentCHAT Electron application
set -e # Exit immediately if a command exits with a non-zero status.

echo "🧹 Cleaning previous builds..."
rm -rf build/
rm -rf dist/

echo "📦 Installing dependencies..."
npm ci

echo "🔨 Compiling and packaging for all platforms (macOS, Windows, Linux)..."
# This command uses electron-builder to build for macOS, Windows, and Linux
# It will create DMGs, EXEs with installers, and AppImages/debs/rpms by default
npm run build -- --mac --win --linux

echo "✅ Build complete! Check the 'dist/' folder for packages."
ls -l dist/