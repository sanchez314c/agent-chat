# Usage Guide

## 🎯 Getting Started

Once you have AgentCHAT installed and configured with at least one AI agent, you're ready to start conversations!

## 💬 Basic Conversation Flow

### 1. Creating a New Conversation

1. **Click "New Conversation"** in the top toolbar
2. **Or use keyboard shortcut**:
   - Windows/Linux: `Ctrl+N`
   - macOS: `Cmd+N`

### 2. Adding Agents to Conversation

1. **Click "Add Agents"** in the conversation panel
2. **Select agents** you want to participate:
   - Single agent: One-on-one conversation
   - Multiple agents: Compare responses from different AIs
3. **Click "Start Conversation"**

### 3. Sending Messages

1. **Type your message** in the input field at the bottom
2. **Press `Enter`** or click the "Send" button
3. **Watch responses** appear in real-time from each agent

## 🎨 Interface Overview

```
┌─────────────────────────────────────────────────────┐
│  📱 AgentCHAT                    [Settings] [Help] │
├─────────────────────────────────────────────────────┤
│  [+ New]  [💾 Save]  [📤 Export]  [🔄 Refresh]    │
├─────────────────────────────────────────────────────┤
│                                                     │
│  🤖 Claude 3.5 Sonnet           👤 GPT-4            │
│  ┌─────────────────────────┐   ┌─────────────────┐ │
│  │ I can help with that!  │   │ Let me explain  │ │
│  │ The best approach is   │   │ this concept...  │ │
│  │ to use TypeScript for  │   │                 │ │
│  │ type safety.           │   │ Here's how...    │ │
│  └─────────────────────────┘   └─────────────────┘ │
│                                                     │
│  👤 Gemini 1.5 Pro             🤖 Llama 2          │
│  ┌─────────────────────────┐   ┌─────────────────┐ │
│  │ Building modern apps   │   │ I can suggest   │ │
│  │ requires careful...    │   │ these patterns  │ │
│  └─────────────────────────┘   └─────────────────┘ │
│                                                     │
├─────────────────────────────────────────────────────┤
│  ┌───────────────────────────────────────────────┐ │
│  │ Type your message here...                      │ │
│  └───────────────────────────────────────────────┘ │
│  [Send] 📎                                         │
└─────────────────────────────────────────────────────┘
```

## 🚀 Advanced Features

### Multi-Agent Comparison

**Compare responses** from different AI models on the same question:

1. **Add multiple agents** (2-4 recommended)
2. **Ask the same question** to all agents
3. **Compare responses** side-by-side
4. **Use insights** from each model

**Use Cases:**
- **Content Creation**: Get different writing styles
- **Problem Solving**: Compare approaches and solutions
- **Learning**: Understand concepts from multiple perspectives
- **Code Review**: Get different code suggestions

### Conversation Management

#### Saving Conversations
1. **Click "💾 Save"** in the toolbar
2. **Enter a descriptive name**
3. **Conversation is saved** with all agent responses

#### Loading Conversations
1. **Click "📁 Open"** in the toolbar
2. **Select saved conversation** from the list
3. **Continue the conversation** or review past responses

#### Exporting Conversations
1. **Click "📤 Export"** in the toolbar
2. **Choose export format**:
   - **Markdown**: Clean text format with formatting
   - **JSON**: Structured data for analysis
   - **PDF**: Printable document
3. **Save to desired location**

### Agent Customization

#### Creating Specialized Agents

1. **Open Agent Settings** (`Edit → Agent Settings`)
2. **Click "Add New Agent"**
3. **Configure specialized behavior**:

**Example: Code Review Agent**
```
Name: "Code Reviewer"
Provider: Claude 3.5 Sonnet
System Prompt: "You are an expert code reviewer. Focus on:
- Code quality and best practices
- Security vulnerabilities
- Performance optimizations
- Maintainability and readability
Provide specific, actionable feedback."
Temperature: 0.3 (more focused)
```

**Example: Creative Writing Agent**
```
Name: "Creative Writer"
Provider: GPT-4
System Prompt: "You are a creative writing assistant. Help with:
- Story development and plotting
- Character creation
- Dialogue writing
- Style and tone suggestions
Be imaginative and encouraging."
Temperature: 0.8 (more creative)
```

#### Context Window Management

- **Short conversations**: Use smaller context windows (4k-8k tokens)
- **Long conversations**: Use larger context windows (16k-32k tokens)
- **Code projects**: Prioritize recent code over older context

## 🎯 Best Practices

### Effective Prompting

1. **Be specific** about what you want
2. **Provide context** for complex questions
3. **Break down** large requests into smaller parts
4. **Use examples** when asking for specific formats
5. **Iterate** and refine your prompts

### Multi-Agent Strategies

1. **Start with 2-3 agents** to avoid overwhelming
2. **Choose complementary models** (e.g., Claude for reasoning, GPT-4 for creativity)
3. **Compare approaches** rather than just answers
4. **Use specialized agents** for specific tasks

### Conversation Organization

1. **Use descriptive names** for saved conversations
2. **Export important conversations** for reference
3. **Create conversation templates** for recurring tasks
4. **Regularly clean up** old conversations

## ⌨️ Keyboard Shortcuts

| Shortcut | Windows/Linux | macOS | Function |
|----------|---------------|-------|----------|
| `Ctrl+N` / `Cmd+N` | ✅ | ✅ | New Conversation |
| `Ctrl+S` / `Cmd+S` | ✅ | ✅ | Save Conversation |
| `Ctrl+O` / `Cmd+O` | ✅ | ✅ | Open Conversation |
| `Ctrl+E` / `Cmd+E` | ✅ | ✅ | Export Conversation |
| `Ctrl+Enter` | ✅ | ✅ | Send Message |
| `Ctrl+/` | ✅ | ✅ | Toggle Settings |
| `F5` | ✅ | - | Refresh Agents |

## 🔧 Troubleshooting Usage Issues

### Agents Not Responding

1. **Check API key** is valid and has credits
2. **Verify network connection** is stable
3. **Try restarting** the application
4. **Check rate limits** for your API plan

### Slow Response Times

1. **Reduce max tokens** in agent settings
2. **Use smaller context windows**
3. **Close unused conversations**
4. **Choose faster models** (e.g., Claude 3 Haiku for quick responses)

### Conversation History Issues

1. **Save frequently** to avoid losing context
2. **Export important conversations** as backup
3. **Start new conversations** for different topics
4. **Clear cache** if application becomes slow

## 📚 Advanced Use Cases

### Software Development

1. **Code Generation**: Use specialized coding agents
2. **Code Review**: Compare feedback from multiple models
3. **Documentation**: Generate comprehensive docs
4. **Debugging**: Get different perspectives on issues

### Content Creation

1. **Blog Posts**: Use agents for outline, writing, and editing
2. **Social Media**: Generate platform-specific content
3. **Technical Writing**: Create clear, accurate documentation
4. **Creative Writing**: Develop stories and characters

### Research & Analysis

1. **Literature Review**: Summarize research papers
2. **Data Analysis**: Get insights from data
3. **Market Research**: Analyze trends and opportunities
4. **Learning**: Understand complex topics

---

*For more advanced features, see the [Feature Guide](features.md).*