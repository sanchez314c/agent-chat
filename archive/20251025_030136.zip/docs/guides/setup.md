# Setup Guide

## 📋 Prerequisites

### System Requirements
- **Operating System**: Windows 10+, macOS 10.14+, or Linux (Ubuntu 18.04+)
- **Memory**: 4GB RAM minimum (8GB recommended)
- **Storage**: 500MB available space
- **Network**: Internet connection for AI provider APIs

### Required Accounts
- **AI Provider Accounts**: At least one of:
  - [Anthropic Claude](https://console.anthropic.com/) API key
  - [OpenAI](https://platform.openai.com/) API key
  - [Google AI Studio](https://aistudio.google.com/) API key
  - [OpenRouter](https://openrouter.ai/) API key

## 🚀 Installation Options

### Option 1: Download Pre-built Release (Recommended)

1. **Download the latest release**
   - Visit [GitHub Releases](https://github.com/spacewelder314/AgentCHAT/releases)
   - Download the appropriate file for your platform:
     - macOS: `AgentCHAT-1.0.0.dmg`
     - Windows: `AgentCHAT Setup 1.0.0.exe`
     - Linux: `AgentCHAT-1.0.0.AppImage`

2. **Install the application**

   **macOS:**
   ```bash
   # Open the downloaded DMG file
   open ~/Downloads/AgentCHAT-1.0.0.dmg

   # Drag AgentCHAT to Applications folder
   ```

   **Windows:**
   ```bash
   # Run the installer
   ~/Downloads/AgentCHAT\ Setup\ 1.0.0.exe

   # Follow the installation wizard
   ```

   **Linux:**
   ```bash
   # Make the AppImage executable
   chmod +x ~/Downloads/AgentCHAT-1.0.0.AppImage

   # Run the application
   ~/Downloads/AgentCHAT-1.0.0.AppImage
   ```

### Option 2: Build from Source

1. **Clone the repository**
   ```bash
   git clone https://github.com/spacewelder314/AgentCHAT.git
   cd AgentCHAT
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Build and run**
   ```bash
   # Development mode with hot reload
   npm run electron:dev

   # Or build for production
   npm run build
   npm run electron:preview
   ```

## ⚙️ First-Time Setup

### 1. Launch AgentCHAT
- **macOS**: Open Launchpad and click AgentCHAT
- **Windows**: Search for AgentCHAT in Start Menu
- **Linux**: Run the AppImage or installed application

### 2. Configure AI Providers

1. **Open Agent Configuration**
   - Click the "Agent Settings" button in the top toolbar
   - Or use menu: `Edit → Agent Settings`

2. **Add Your First Agent**
   - Click "Add New Agent"
   - Select AI Provider (e.g., "Claude")
   - Choose Model (e.g., "Claude 3.5 Sonnet")
   - Enter your API key
   - Configure agent settings:
     - **Name**: Descriptive name (e.g., "Claude Assistant")
     - **System Prompt**: Optional behavior instructions
     - **Temperature**: 0.0 (focused) to 1.0 (creative)
     - **Max Tokens**: Response length limit

3. **Save Configuration**
   - Click "Save Agent"
   - API keys are encrypted and stored securely

### 3. Start Your First Conversation

1. **Create New Conversation**
   - Click "New Conversation" button
   - Or use keyboard shortcut: `Ctrl+N` (Windows/Linux) or `Cmd+N` (macOS)

2. **Add Agents to Conversation**
   - Click "Add Agents"
   - Select agents you want to include
   - Click "Start Conversation"

3. **Send Your First Message**
   - Type your message in the input field
   - Press `Enter` or click "Send"
   - Watch as multiple agents respond simultaneously

## 🔧 Configuration Options

### Agent Settings
- **Provider**: AI service provider
- **Model**: Specific AI model to use
- **API Key**: Encrypted storage of API key
- **System Prompt**: Custom instructions for the AI
- **Temperature**: Response randomness (0.0-1.0)
- **Max Tokens**: Maximum response length
- **Context Window**: Conversation history limit

### Application Settings
- **Theme**: Dark/Light mode (coming soon)
- **Auto-save**: Automatically save conversations
- **Export format**: Conversation export format
- **Update notifications**: Automatic update checking

## 🐛 Troubleshooting

### Common Issues

#### "API Key Invalid"
- Verify API key is correct
- Check if API key has credits/quota
- Ensure API key is properly copied (no extra spaces)

#### "Network Connection Failed"
- Check internet connection
- Verify firewall settings
- Try different network (some corporate networks block AI APIs)

#### "Application Won't Start"
- **macOS**: "AgentCHAT can't be opened because Apple cannot check it for malicious software"
  ```bash
  # Allow application to run
  xattr -d com.apple.quarantine /Applications/AgentCHAT.app
  ```

- **Windows**: "Windows protected your PC"
  - Click "More info"
  - Click "Run anyway"

#### "Out of Memory"
- Close other applications to free memory
- Reduce max tokens in agent settings
- Restart AgentCHAT application

### Getting Help

1. **Check the [Troubleshooting Guide](troubleshooting.md)**
2. **Search existing [GitHub Issues](https://github.com/spacewelder314/AgentCHAT/issues)**
3. **Create a new issue** with:
   - Operating system and version
   - AgentCHAT version
   - Error messages or screenshots
   - Steps to reproduce the issue

## 📚 Next Steps

- [Usage Guide](usage.md) - Learn how to use AgentCHAT effectively
- [Feature Guide](features.md) - Explore advanced features
- [API Documentation](../technical/api/README.md) - Understand the technical implementation
- [Contributing Guide](../development/CONTRIBUTING.md) - Contribute to the project

---

## 🔗 Useful Links

- [GitHub Repository](https://github.com/spacewelder314/AgentCHAT)
- [Issue Tracker](https://github.com/spacewelder314/AgentCHAT/issues)
- [Discord Community](https://discord.gg/) (coming soon)
- [Documentation Home](../README.md)

---

*Need help? Open an issue on [GitHub](https://github.com/spacewelder314/AgentCHAT/issues).*