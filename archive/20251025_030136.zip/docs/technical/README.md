# Technical Documentation

This section contains technical documentation for developers working on AgentCHAT.

## 📋 Contents

### [Architecture](architecture.md)
- System overview and design patterns
- Component relationships
- Data flow diagrams

### [Technology Stack](../TECH-STACK.md)
- Frameworks and libraries
- Build tools and configuration
- Development environment setup

### API Documentation
- Coming soon: API endpoints and interfaces
- Component props and methods
- Service APIs

### Build & Deployment
- [Build System Guide](deployment/BUILD_SYSTEM_GUIDE.md)
- [Build Scripts Reference](deployment/build-scripts.md)
- Release procedures

## 🔧 Development Environment

### Prerequisites
- Node.js 18+
- npm or yarn
- Git

### Setup
```bash
# Clone repository
git clone https://github.com/spacewelder314/AgentCHAT.git
cd AgentCHAT

# Install dependencies
npm install

# Start development
npm run electron:dev
```

### Build Commands
```bash
# Development build
npm run build

# Production build
npm run dist

# Platform-specific builds
npm run dist:mac    # macOS
npm run dist:win    # Windows
npm run dist:linux  # Linux
```

## 🏗️ Project Structure

```
src/
├── main.cjs          # Electron main process
├── preload.cjs       # Preload script
├── App.tsx           # React application entry
├── components/       # React components
├── services/         # Business logic
└── types/           # TypeScript definitions
```

## 🧪 Testing

- Unit tests: `tests/unit/`
- Integration tests: `tests/integration/`
- E2E tests: `tests/e2e/`