# Documentation

Welcome to the AgentCHAT documentation hub. This page provides navigation to all available documentation.

## 📚 Documentation Structure

### 🏗️ [Technical Documentation](technical/)
- [Architecture](technical/architecture.md) - System design and architecture
- [Technology Stack](../TECH-STACK.md) - Technologies used in this project
- [API Documentation](technical/api/) - API references and endpoints
- [Build System](technical/deployment/) - Build and deployment guides

### 👨‍💻 [Development Guides](development/)
- [Development Setup](development/) - Environment configuration
- [Testing Guide](development/testing.md) - Testing strategies
- [Code Style](development/style-guide.md) - Coding conventions

### 📖 [User Guides](guides/)
- [Setup Guide](guides/setup.md) - Installation and configuration
- [Usage Guide](guides/usage.md) - How to use the application

### 🔧 [Internal Documentation](internal/)
- [Learnings](internal/learnings.md) - Development insights and lessons learned
- [TODO List](internal/todo.md) - Project roadmap and tasks

### 📜 [Legacy Archive](legacy/)
- [Archive Contents](legacy/) - Historical documentation and implementations

## 🚀 Quick Start

1. **Installation**: See [Setup Guide](guides/setup.md)
2. **Development**: Run `npm run electron:dev`
3. **Build**: Run `npm run dist`

## 🤝 Contributing

See [CONTRIBUTING.md](../CONTRIBUTING.md) for guidelines on contributing to this project.