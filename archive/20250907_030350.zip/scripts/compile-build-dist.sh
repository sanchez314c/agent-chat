#!/bin/bash

# Complete Multi-Platform Build Script
# Builds for macOS, Windows, and Linux with all installer types

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Get the script directory and go to project root
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR/.."

# Function to print colored output
print_status() {
    echo -e "${BLUE}[$(date +'%H:%M:%S')]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[$(date +'%H:%M:%S')] ✔${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[$(date +'%H:%M:%S')] ⚠${NC} $1"
}

print_error() {
    echo -e "${RED}[$(date +'%H:%M:%S')] ✗${NC} $1"
}

print_info() {
    echo -e "${CYAN}[$(date +'%H:%M:%S')] ℹ${NC} $1"
}

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Function to display help
show_help() {
    echo "Complete Multi-Platform Build Script"
    echo ""
    echo "Usage: ./compile-build-dist.sh [options]"
    echo ""
    echo "Options:"
    echo "  --no-clean         Skip cleaning build artifacts"
    echo "  --platform PLAT    Build for specific platform (mac, win, linux, all)"
    echo "  --arch ARCH        Build for specific architecture (x64, ia32, arm64, all)"
    echo "  --quick            Quick build (single platform only)"
    echo "  --help             Display this help message"
    echo ""
    echo "Examples:"
    echo "  ./compile-build-dist.sh                    # Full build for all platforms"
    echo "  ./compile-build-dist.sh --platform win     # Windows only"
    echo "  ./compile-build-dist.sh --quick            # Quick build for current platform"
    echo "  ./compile-build-dist.sh --no-clean         # Build without cleaning first"
}

# Parse command line arguments
NO_CLEAN=false
PLATFORM="all"
ARCH="all"
QUICK=false

while [[ $# -gt 0 ]]; do
    case $1 in
        --no-clean)
            NO_CLEAN=true
            shift
            ;;
        --platform)
            PLATFORM="$2"
            shift 2
            ;;
        --arch)
            ARCH="$2"
            shift 2
            ;;
        --quick)
            QUICK=true
            shift
            ;;
        --help)
            show_help
            exit 0
            ;;
        *)
            print_error "Unknown option: $1"
            show_help
            exit 1
            ;;
    esac
done

# Check for required tools
print_status "Checking requirements..."

if ! command_exists node; then
    print_error "Node.js is not installed. Please install Node.js first."
    exit 1
fi

if ! command_exists npm; then
    print_error "npm is not installed. Please install npm first."
    exit 1
fi

print_success "All requirements met"

# Step 1: Clean everything if not skipped
if [ "$NO_CLEAN" = false ]; then
    print_status "🧹 Purging all existing builds..."
    rm -rf dist/
    rm -rf build/
    rm -rf node_modules/.cache/
    rm -rf out/
    rm -rf release/
    print_success "All build artifacts purged"
fi

# Step 2: Install/update dependencies
print_status "📦 Checking dependencies..."
if [ ! -d "node_modules" ]; then
    print_status "Installing dependencies..."
    npm install
    if [ $? -ne 0 ]; then
        print_error "Failed to install dependencies"
        exit 1
    fi
fi

# Install electron-builder if not present
if ! npm list electron-builder >/dev/null 2>&1; then
    print_status "Installing electron-builder..."
    npm install --save-dev electron-builder
fi

print_success "Dependencies ready"

# Step 3: TypeScript compilation
print_status "🔨 Compiling TypeScript..."
npx tsc --noEmit
if [ $? -ne 0 ]; then
    print_warning "TypeScript compilation warnings detected"
fi

# Step 4: Build React app
print_status "⚛️ Building React application..."
npm run build
if [ $? -ne 0 ]; then
    print_error "React build failed"
    exit 1
fi
print_success "React build completed"

# Step 5: Determine build targets
print_status "🎯 Determining build targets..."
BUILD_CMD="npm run dist"

if [ "$QUICK" = true ]; then
    print_info "Quick build mode - building for current platform only"
    BUILD_CMD="npm run dist:current"
elif [ "$PLATFORM" != "all" ]; then
    case $PLATFORM in
        mac)
            BUILD_CMD="npm run dist:mac"
            print_info "Building for macOS only"
            ;;
        win)
            BUILD_CMD="npm run dist:win"
            print_info "Building for Windows only"
            ;;
        linux)
            BUILD_CMD="npm run dist:linux"
            print_info "Building for Linux only"
            ;;
        *)
            print_error "Invalid platform: $PLATFORM"
            exit 1
            ;;
    esac
else
    print_info "Building for all platforms"
fi

# Step 6: Build all platform binaries and packages
print_status "🏗️ Building platform binaries and packages..."
print_status "Targets: macOS (Intel + ARM), Windows (x64 + x86), Linux (x64)"
print_status "Installers: .dmg, .exe, .msi, .deb, .rpm, .AppImage, .snap"

# Detect number of CPU cores
CPU_CORES=$(sysctl -n hw.ncpu 2>/dev/null || nproc 2>/dev/null || echo 4)
print_info "🚀 Using $CPU_CORES CPU cores for parallel build"

# Set environment variables for parallel builds
export ELECTRON_BUILDER_CONCURRENT=true
export ELECTRON_BUILDER_MAX_CONCURRENCY=$CPU_CORES
export UV_THREADPOOL_SIZE=$CPU_CORES

# Run the build with parallel processing
$BUILD_CMD
BUILD_RESULT=$?

if [ $BUILD_RESULT -ne 0 ]; then
    print_error "Build failed"
    exit 1
fi

print_success "All platform builds completed successfully"

# Step 6.5: Rename output folders to match standards
print_status "📁 Standardizing output folder names..."

# Rename Windows folders to standard naming
if [ -d "dist/win-unpacked" ]; then
    mv "dist/win-unpacked" "dist/win-x64-unpacked"
    print_info "Renamed: win-unpacked → win-x64-unpacked"
fi

if [ -d "dist/win-ia32-unpacked" ]; then
    mv "dist/win-ia32-unpacked" "dist/win-x32-unpacked"
    print_info "Renamed: win-ia32-unpacked → win-x32-unpacked"
fi

# macOS folders (mac/ and mac-arm64/) are usually correct
# linux-unpacked is already correct

print_success "Folder naming standardized"

# Step 7: Display build results
print_status "📋 Build Results Summary:"
echo ""
echo -e "${PURPLE}════════════════════════════════════════════════════════${NC}"

if [ -d "dist" ] || [ -d "release" ]; then
    BUILD_DIR="dist"
    
    # Count files by type
    MAC_COUNT=$(find $BUILD_DIR -name "*.dmg" -o -name "*.zip" 2>/dev/null | grep -E "(mac|darwin)" | wc -l)
    WIN_COUNT=$(find $BUILD_DIR -name "*.exe" -o -name "*.msi" -o -name "*-win.zip" 2>/dev/null | wc -l)
    LINUX_COUNT=$(find $BUILD_DIR -name "*.AppImage" -o -name "*.deb" -o -name "*.rpm" -o -name "*.snap" 2>/dev/null | wc -l)
    
    print_info "📊 Build Statistics:"
    echo "   macOS packages: $MAC_COUNT"
    echo "   Windows packages: $WIN_COUNT"
    echo "   Linux packages: $LINUX_COUNT"
    echo ""
    
    # macOS builds
    if [ $MAC_COUNT -gt 0 ]; then
        print_success "🍎 macOS Builds:"
        find $BUILD_DIR -name "*.dmg" -type f 2>/dev/null | while read -r dmg; do
            size=$(ls -lh "$dmg" | awk '{print $5}')
            echo "   ✓ DMG: $(basename "$dmg") ($size)"
        done
        echo ""
    fi
    
    # Windows builds
    if [ $WIN_COUNT -gt 0 ]; then
        print_success "🪟 Windows Builds:"
        find $BUILD_DIR -name "*.exe" -type f 2>/dev/null | while read -r exe; do
            size=$(ls -lh "$exe" | awk '{print $5}')
            echo "   ✓ EXE: $(basename "$exe") ($size)"
        done
        find $BUILD_DIR -name "*.msi" -type f 2>/dev/null | while read -r msi; do
            size=$(ls -lh "$msi" | awk '{print $5}')
            echo "   ✓ MSI: $(basename "$msi") ($size)"
        done
        echo ""
    fi
    
    # Linux builds
    if [ $LINUX_COUNT -gt 0 ]; then
        print_success "🐧 Linux Builds:"
        find $BUILD_DIR -name "*.AppImage" -type f 2>/dev/null | while read -r app; do
            size=$(ls -lh "$app" | awk '{print $5}')
            echo "   ✓ AppImage: $(basename "$app") ($size)"
        done
        find $BUILD_DIR -name "*.deb" -type f 2>/dev/null | while read -r deb; do
            size=$(ls -lh "$deb" | awk '{print $5}')
            echo "   ✓ DEB: $(basename "$deb") ($size)"
        done
        find $BUILD_DIR -name "*.rpm" -type f 2>/dev/null | while read -r rpm; do
            size=$(ls -lh "$rpm" | awk '{print $5}')
            echo "   ✓ RPM: $(basename "$rpm") ($size)"
        done
        echo ""
    fi
else
    print_warning "No dist or release directory found. Build may have failed."
fi

echo ""
echo -e "${PURPLE}════════════════════════════════════════════════════════${NC}"
print_success "🎉 Complete build process finished!"
print_status "📁 All binaries and packages are in: ./$BUILD_DIR/"
print_status ""
print_info "To run the application:"
print_info "  macOS:   ./scripts/run-macos-source.sh (dev) or ./scripts/run-macos.sh (binary)"
print_info "  Windows: scripts\\run-windows-source.bat (dev) or scripts\\run-windows.bat (binary)"
print_info "  Linux:   ./scripts/run-linux-source.sh (dev) or ./scripts/run-linux.sh (binary)"