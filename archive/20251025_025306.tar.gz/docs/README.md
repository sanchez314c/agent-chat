# AgentCHAT Documentation

![Version](https://img.shields.io/badge/version-1.0.0-blue)
![Status](https://img.shields.io/badge/status-active-green)
![License](https://img.shields.io/badge/license-MIT-yellow)

## 📖 Navigation

### 🚀 Quick Start
- [Setup Guide](guides/setup.md) - Installation & getting started
- [Usage Guide](guides/usage.md) - Basic usage tutorial
- [Main README](../README.md) - Project overview

### 👥 For Users
- [Setup Instructions](guides/setup.md)
- [Usage Tutorial](guides/usage.md)
- [Feature Guide](guides/features.md)
- [Troubleshooting](guides/troubleshooting.md)

### 👨‍💻 For Developers
- [Development Setup](development/README.md)
- [Architecture Overview](technical/architecture.md)
- [API Reference](technical/api/README.md)
- [Code of Conduct](../CODE_OF_CONDUCT.md)

### 🏗️ Technical Documentation
- [Technology Stack](technical/tech-stack.md)
- [System Architecture](technical/architecture.md)
- [API Documentation](technical/api/README.md)
- [Security Documentation](technical/security.md)
- [Build System](technical/deployment/build-system.md)

### 📋 Project Management
- [Product Requirements](../dev/PRDs/PRD.md)
- [Project Roadmap](internal/todo.md)
- [Learning Journey](internal/learnings.md)
- [Contributing Guide](development/CONTRIBUTING.md)

### 🔧 Internal Documentation
- [Development Notes](internal/notes.md)
- [Version Planning](internal/version-map.md)
- [Legacy Archive](legacy/README.md)

---

## 📁 Documentation Structure

```
docs/
├── technical/           # Technical architecture and reference
│   ├── api/            # API documentation
│   ├── deployment/     # Build and deployment guides
│   └── security.md     # Security documentation
├── development/         # Development workflows and guides
│   └── CONTRIBUTING.md # Contributing guidelines
├── guides/             # User guides and tutorials
├── internal/           # Internal project documentation
└── legacy/             # Archived documentation
```

---

## 🔍 Quick Links

- **Installation**: See [Setup Guide](guides/setup.md)
- **API Reference**: See [API Documentation](technical/api/README.md)
- **Contributing**: See [Contributing Guide](development/CONTRIBUTING.md)
- **Reporting Issues**: [GitHub Issues](https://github.com/spacewelder314/AgentCHAT/issues)

---

## 📄 License

See [LICENSE](../LICENSE) for full license information.

---

*Last updated: 2025-10-25*