# System Architecture

## 🏗️ Overview

AgentCHAT follows the **Electron application pattern** with clear separation between processes and responsibilities.

## 🔄 Process Architecture

### Main Process (`src/main.cjs`)
**Responsibilities:**
- Application lifecycle management
- Window creation and management
- File system access
- Secure storage operations
- IPC server implementation
- AI provider API communication

**Key Components:**
- `BrowserWindow` management
- `electron-store` for encrypted configuration
- IPC handlers for renderer communication
- HTTP client for AI provider APIs

### Renderer Process (`src/` React App)
**Responsibilities:**
- User interface rendering
- User interaction handling
- Conversation display
- Agent configuration UI
- Real-time updates

**Key Components:**
- React functional components with hooks
- Tailwind CSS for styling
- State management with React hooks
- Lucide React for icons

### Preload Script (`src/preload.cjs`)
**Responsibilities:**
- Secure IPC bridge
- Context isolation enforcement
- Exposed API to renderer
- Security boundary enforcement

## 🔐 Security Architecture

### Context Isolation
- **Enabled**: Renderer cannot access Node.js APIs directly
- **Sandbox**: Web content runs in isolated context
- **Preload Bridge**: Controlled API exposure to renderer

### Secure Storage
```javascript
// Per-installation encryption key generation
const encryptionKey = crypto.scryptSync(machineId, 'salt', 32);

// Encrypted configuration storage
const store = new Store({
  encryptionKey,
  name: 'agentchat-config'
});
```

### IPC Security
- All main/renderer communication through defined channels
- Input validation on all IPC calls
- No direct Node.js API exposure

## 🧠 Agent Architecture

### Provider Abstraction
```javascript
interface AIProvider {
  name: string;
  models: Model[];
  sendMessage(config: AgentConfig, message: string): Promise<string>;
}
```

### Supported Providers
- **Anthropic**: Claude 3.5 Sonnet, Claude 3 Opus, Claude 3 Haiku
- **OpenAI**: GPT-4, GPT-4 Turbo, GPT-3.5 Turbo
- **Google**: Gemini 1.5 Pro, Gemini 1.5 Flash
- **OpenRouter**: Access to open-source models

### Agent Configuration
Each agent configured with:
- Provider selection and model variant
- System persona and behavior instructions
- Temperature, max tokens, context window settings
- Secure API key storage

## 📊 Data Flow

### Conversation Flow
1. User enters message in React UI
2. Message sent via IPC to main process
3. Main process formats request for each agent
4. Parallel API calls to AI providers
5. Responses collected and stored
6. Results sent back to renderer via IPC
7. UI updates with agent responses

### Configuration Flow
1. User configures agent in UI
2. Configuration validated and sent via IPC
3. Main process stores in encrypted storage
4. API keys encrypted with machine-specific key
5. Configuration persisted across restarts

## 🗂️ File Structure

```
src/
├── components/              # React UI components
│   ├── AgentConfigPanel.tsx # Agent settings and configuration
│   ├── ConversationPanel.tsx # Main chat interface
│   ├── MessageBubble.tsx    # Individual message display
│   ├── StatusBar.tsx        # Bottom status bar
│   └── APIKeyModal.tsx      # Secure API key configuration
├── services/                # Business logic layer
│   ├── AgentManager.ts      # Core agent orchestration
│   └── APIClient.ts         # AI provider API clients
├── types/                   # TypeScript definitions
├── App.tsx                  # Main React application
├── main.tsx                 # React entry point
├── main.cjs                 # Electron main process
└── preload.cjs              # Secure IPC bridge
```

## 🔧 Technical Patterns

### React Patterns
- **Functional Components**: Only functional components with hooks
- **Props Destructuring**: Destructure props in component parameters
- **Custom Hooks**: Complex state logic extracted to custom hooks
- **State Management**: React hooks (useState, useEffect, useCallback, useRef)

### TypeScript Patterns
- **Strict Mode**: Full TypeScript strict mode enabled
- **Path Mapping**: `@/*` resolves to `./src/*`
- **Interface Definitions**: Comprehensive type definitions for all data structures
- **Error Handling**: Typed error handling with proper error types

### Security Patterns
- **Input Validation**: All user inputs validated before processing
- **Sanitization**: API responses sanitized before display
- **Secure Defaults**: Secure-by-default configuration
- **Principle of Least Privilege**: Minimal API exposure

## 🚀 Build Architecture

### Development Build
- **Vite Dev Server**: Hot module replacement for React UI
- **Electron Reload**: Automatic restart on main process changes
- **Concurrent Process**: Development server and Electron run concurrently

### Production Build
1. **TypeScript Compilation**: `tsc` compiles TypeScript
2. **Vite Build**: Bundles React application
3. **Electron Builder**: Creates platform-specific installers
4. **Code Signing**: Optional code signing for distribution

### Platform Support
- **macOS**: DMG, PKG, ZIP, App Store (MAS)
- **Windows**: EXE, MSI, ZIP, Portable, Microsoft Store
- **Linux**: AppImage, DEB, RPM, SNAP, TAR.GZ

---

*For API documentation, see [API Reference](api/README.md).*