#!/bin/bash
# scripts/validate-standards.sh

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$PROJECT_ROOT"

SCORE=0
MAX=10

echo "🔍 Validating Project Standards..."
echo "================================"

# Check documentation
echo "📚 Checking documentation..."

if [ -f "README.md" ]; then
    ((SCORE++))
    echo "✅ README.md found"
else
    echo "❌ README.md missing"
fi

if [ -f "LICENSE" ]; then
    ((SCORE++))
    echo "✅ LICENSE found"
else
    echo "❌ LICENSE missing"
fi

if [ -f "CHANGELOG.md" ]; then
    ((SCORE++))
    echo "✅ CHANGELOG.md found"
else
    echo "❌ CHANGELOG.md missing"
fi

if [ -f "docs/README.md" ]; then
    ((SCORE++))
    echo "✅ Documentation index found"
else
    echo "❌ Documentation index missing"
fi

# Check structure
echo ""
echo "📁 Checking project structure..."

if [ -d "src" ]; then
    ((SCORE++))
    echo "✅ src/ directory found"
else
    echo "❌ src/ directory missing"
fi

if [ -d "tests" ]; then
    ((SCORE++))
    echo "✅ tests/ directory found"
else
    echo "❌ tests/ directory missing"
fi

if [ -d "docs" ]; then
    ((SCORE++))
    echo "✅ docs/ directory found"
else
    echo "❌ docs/ directory missing"
fi

# Check configuration
echo ""
echo "⚙️  Checking configuration..."

if [ -f ".env.example" ]; then
    ((SCORE++))
    echo "✅ .env.example found"
else
    echo "❌ .env.example missing"
fi

if [ -d "config" ]; then
    ((SCORE++))
    echo "✅ config/ directory found"
else
    echo "❌ config/ directory missing"
fi

# Check professional
echo ""
echo "🎨 Checking professional presentation..."

if [ -d "assets/screenshots" ] || [ -d "assets/images" ]; then
    ((SCORE++))
    echo "✅ assets/ directory found"
else
    echo "❌ assets/ directory missing"
fi

if [ -f "docs/technical/tech-stack.md" ]; then
    ((SCORE++))
    echo "✅ TECH-STACK.md found"
else
    echo "❌ TECH-STACK.md missing"
fi

echo ""
echo "================================"
echo "📊 Standardization Score: $SCORE/$MAX"

if [ $SCORE -ge 8 ]; then
    echo "✅ PASSED - Project meets standards"
    exit 0
else
    echo "⚠️  NEEDS WORK - Score below 8/10"
    exit 1
fi