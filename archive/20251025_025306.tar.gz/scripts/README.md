# Scripts Directory

This directory contains all automation scripts for the AgentCHAT project.

## 🚀 Primary Scripts

### Development Scripts
- **`run-macos-source.sh`** - Run from source on macOS (development mode)
- **`run-linux-source.sh`** - Run from source on Linux (development mode)
- **`run-windows-source.bat`** - Run from source on Windows (development mode)

### Build Scripts
- **`build-compile-dist.sh`** - Master build script (cleans, builds, packages for all platforms)
- **`compile-build-dist.sh`** - Comprehensive multi-platform build with monitoring
- **`build-release-run.sh`** - Build and run for current platform

### Distribution Scripts
- **`run-macos.sh`** - Run compiled application on macOS
- **`run-linux.sh`** - Run compiled application on Linux
- **`run-windows.bat`** - Run compiled application on Windows

## 🧹 Maintenance Scripts

- **`temp-cleanup.sh`** - Clean temporary files and directories
- **`bloat-check.sh`** - Monitor bundle size and detect bloat
- **`clean-logs.js`** - Clean application logs

## 📋 Usage Examples

### Development (Most Common)
```bash
# Start development server with hot reload
./scripts/run-macos-source.sh    # macOS
./scripts/run-linux-source.sh    # Linux
scripts\run-windows-source.bat   # Windows
```

### Building for Distribution
```bash
# Quick build for current platform
./scripts/build-release-run.sh

# Build for all platforms (macOS, Windows, Linux)
./scripts/build-compile-dist.sh

# Comprehensive build with monitoring
./scripts/compile-build-dist.sh
```

### Running Built Application
```bash
# Run the built application
./scripts/run-macos.sh      # macOS
./scripts/run-linux.sh      # Linux
scripts\run-windows.bat     # Windows
```

### Maintenance
```bash
# Clean temporary files
./scripts/temp-cleanup.sh

# Check for bundle bloat
./scripts/bloat-check.sh
```

## 🔧 Script Configuration

### Environment Variables
- **`NODE_ENV`** - Set to 'development' for debug builds
- **`SKIP_CLEANUP`** - Skip cleanup steps (set to 'true')
- **`SKIP_BLOAT_CHECK`** - Skip bloat monitoring (set to 'true')

### Build Targets
- **macOS**: DMG, PKG, ZIP, App Store (MAS)
- **Windows**: EXE, MSI, ZIP, Portable, Microsoft Store
- **Linux**: AppImage, DEB, RPM, SNAP, TAR.GZ

## 📊 Build Outputs

### Development
- **Location**: `dist/renderer/` (Vite build output)
- **Format**: Unbundled development files
- **Source Maps**: Included

### Production
- **Location**: `dist/` (Electron Builder output)
- **Format**: Platform-specific installers
- **Compression**: Maximum compression enabled

## 🚨 Important Notes

1. **Always run from project root** - All scripts expect to be run from the project root directory
2. **Dependencies first** - Scripts will automatically install dependencies if needed
3. **Platform specific** - Use the correct script for your platform
4. **Clean builds** - Production builds always start with clean directories
5. **Error handling** - All scripts include proper error handling and status messages

## 🔄 CI/CD Integration

These scripts are designed to work seamlessly with the GitHub Actions workflow:

```yaml
# Example from .github/workflows/ci.yml
- name: Build application
  run: npm run build

- name: Build Electron app
  run: npm run pack
```

## 📝 Adding New Scripts

When adding new scripts:

1. **Use consistent naming**: `kebab-case.sh` for shell scripts
2. **Add executable permission**: `chmod +x scripts/your-script.sh`
3. **Include error handling**: Use `set -e` and proper exit codes
4. **Add documentation**: Update this README with usage instructions
5. **Test on all platforms**: Ensure scripts work on macOS, Windows, and Linux

## 🐛 Troubleshooting

### Permission Denied
```bash
chmod +x scripts/*.sh scripts/*.bat
```

### Node.js Not Found
- Install Node.js 18+ from [nodejs.org](https://nodejs.org/)
- Ensure Node.js is in your PATH

### Build Failures
- Check that all dependencies are installed: `npm ci`
- Verify you have enough disk space
- Check system requirements for Electron Builder

### Platform-Specific Issues
- **macOS**: Check Xcode Command Line Tools: `xcode-select --install`
- **Windows**: Install Windows Build Tools: `npm install -g windows-build-tools`
- **Linux**: Install build dependencies: see your distribution's package manager

---

For more information, see the [Build System Guide](../docs/technical/deployment/build-system.md).