# Technical Documentation

## 🏗️ Architecture Overview

AgentCHAT is an **Electron desktop application** with clear separation between processes:

- **Main Process** (`src/main.cjs`): Node.js environment handling file system, storage, window management
- **Renderer Process** (`src/` React app): Chromium environment running the React frontend
- **Preload Script** (`src/preload.cjs`): Secure bridge between main and renderer processes
- **Build Output**: Vite builds React app to `dist/`, Electron packages for distribution to `release/`

## 📚 Technical Documentation Index

### Core Architecture
- [Technology Stack](tech-stack.md) - Complete technology overview
- [System Architecture](architecture.md) - Detailed architecture documentation
- [Security Documentation](security.md) - Security implementation and best practices

### API Documentation
- [API Reference](api/README.md) - Complete API documentation
- [IPC Communication](api/ipc.md) - Inter-process communication patterns

### Build & Deployment
- [Build System Guide](deployment/build-system.md) - Build configuration and scripts
- [Deployment Guide](deployment/deployment.md) - Platform-specific deployment
- [Build Scripts Reference](deployment/build-scripts.md) - Available build commands

### Development
- [Development Setup](../development/README.md) - Environment setup
- [Code Standards](../development/code-standards.md) - Coding conventions
- [Testing Guide](../development/testing.md) - Testing strategies

## 🔧 Key Technical Patterns

### Secure Storage
API keys encrypted using `electron-store` with per-installation encryption keys:
```javascript
// Main process handles all secure storage operations
store = new Store({
  encryptionKey: getEncryptionKey(),
  name: 'agentchat-config'
})
```

### IPC Communication
All main/renderer communication through secure IPC channels defined in preload script

### Agent Architecture
Multi-agent conversation system with pluggable AI providers (Claude, GPT-4, Gemini, OpenRouter)

---

*For development documentation, see the [Development section](../development/README.md).*