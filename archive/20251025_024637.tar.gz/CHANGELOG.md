# CHANGELOG

All notable changes to this project will be documented in this file.

## [Unreleased]

## [1.0.0] - 2024-08-24
### Added
- Initial release of AgentCHAT
- Multi-agent AI conversation interface
- Electron desktop application
- React/TypeScript frontend with Vite
- Cross-platform support (Windows, macOS, Linux)