---
name: Bug report
about: Create a report to help us improve
title: '[BUG] '
labels: bug
assignees: ''
---

## 🐛 Bug Description
Clear and concise description of what the bug is.

## 🔄 To Reproduce
Steps to reproduce the behavior:
1. Go to '...'
2. Click on '....'
3. Scroll down to '....'
4. See error

## ✅ Expected Behavior
A clear and concise description of what you expected to happen.

## 📸 Screenshots
If applicable, add screenshots to help explain your problem.

## 🖥️ Environment Information:
**OS:** [e.g., macOS 14.0, Windows 11, Ubuntu 22.04]

**AgentCHAT Version:** [e.g., 1.0.0]

**Installation Method:** [e.g., DMG installer, built from source, portable]

**Agents Configured:** [e.g., Claude 3.5 Sonnet, GPT-4]

## 📋 Additional Context
Add any other context about the problem here.

## 🔍 Console Errors
If you see any errors in the developer console (F12), please include them here:

```text
Paste console errors here
```

## 📁 Log Files
If applicable, please attach any relevant log files:

- **Console logs**: Use `Ctrl+Shift+I` (Windows/Linux) or `Cmd+Option+I` (macOS) to open developer tools
- **Application logs**: Located at:
  - **macOS**: `~/Library/Logs/AgentCHAT/`
  - **Windows**: `%APPDATA%/AgentCHAT/logs/`
  - **Linux**: `~/.config/AgentCHAT/logs/`