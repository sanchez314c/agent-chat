# Configuration Directory

This directory contains configuration files and settings.

## Purpose
- Environment configuration files
- Application settings and defaults
- Build and deployment configurations
- Development environment setup

## Current Configuration
Configuration files are currently managed in the project root:
- `vite.config.ts` - Vite build configuration
- `tsconfig.json` - TypeScript configuration
- `tailwind.config.js` - Tailwind CSS configuration
- `.env.example` - Environment variable template

## Future
Additional configuration files can be placed here as the project grows.