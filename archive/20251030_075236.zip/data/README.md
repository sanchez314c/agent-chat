# Data Directory

This directory contains application data files.

## Purpose
- Sample data for development and testing
- Default configurations or templates
- Static data used by the application
- Database files or data stores (if applicable)

## Current Usage
This directory is currently empty and ready for future data files as the application evolves.

## Examples
- Sample agent configurations
- Default conversation templates
- Test data for development
- Export/import examples