#!/bin/bash

# Comprehensive Bloat Analysis Script
# Analyzes project dependencies and build artifacts for optimization opportunities

set -e

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Print functions
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_header() {
    echo ""
    echo -e "${BLUE}================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}================================${NC}"
    echo ""
}

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Function to convert bytes to human readable
human_readable() {
    local bytes=$1
    if [ $bytes -lt 1024 ]; then
        echo "${bytes}B"
    elif [ $bytes -lt 1048576 ]; then
        echo "$(( bytes / 1024 ))KB"
    elif [ $bytes -lt 1073741824 ]; then
        echo "$(( bytes / 1048576 ))MB"
    else
        echo "$(( bytes / 1073741824 ))GB"
    fi
}

# Function to perform comprehensive bloat check
comprehensive_bloat_check() {
    print_header "🔍 COMPREHENSIVE BLOAT ANALYSIS"

    # Check if in Node.js project
    if [ ! -f "package.json" ]; then
        print_error "No package.json found."
        return 1
    fi

    PROJECT_NAME=$(grep '"name"' package.json | cut -d'"' -f4)
    print_status "Analyzing project: $PROJECT_NAME"

    # Analyze node_modules size
    if [ -d "node_modules" ]; then
        NODE_SIZE=$(du -sb node_modules 2>/dev/null | cut -f1)
        NODE_SIZE_HR=$(human_readable $NODE_SIZE)

        print_status "Node modules size: $NODE_SIZE_HR"

        if [ $NODE_SIZE -gt 1073741824 ]; then
            print_warning "⚠️  LARGE: Node modules > 1GB - optimization recommended"
        elif [ $NODE_SIZE -gt 536870912 ]; then
            print_warning "⚠️  MEDIUM: Node modules > 500MB - consider cleanup"
        else
            print_success "✓ Node modules size acceptable"
        fi

        print_status "Top 10 largest dependencies:"
        du -sh node_modules/* 2>/dev/null | sort -hr | head -10 | while read size dir; do
            basename_dir=$(basename "$dir")
            if [ ${#size} -gt 4 ] || [[ $size == *"M"* ]] || [[ $size == *"G"* ]]; then
                print_warning "  $size - $basename_dir"
            else
                print_status "  $size - $basename_dir"
            fi
        done
    else
        print_status "No node_modules directory found"
    fi

    # Analyze build artifacts
    if [ -d "dist" ]; then
        DIST_SIZE=$(du -sb dist 2>/dev/null | cut -f1)
        DIST_SIZE_HR=$(human_readable $DIST_SIZE)
        print_status "Build artifacts size: $DIST_SIZE_HR"

        # List largest files in dist
        find dist -type f -exec du -sh {} + 2>/dev/null | sort -hr | head -5 | while read size file; do
            print_status "  $size - $(basename "$file")"
        done
    fi

    # Check for duplicate dependencies
    print_status "Checking for potential duplicate dependencies..."
    if [ -f "package-lock.json" ]; then
        DUPLICATES=$(npm ls --depth=0 2>/dev/null | grep "deduped" | wc -l | tr -d ' ')
        if [ $DUPLICATES -gt 0 ]; then
            print_warning "Found $DUPLICATES potential duplicate dependencies - consider 'npm dedupe'"
        else
            print_success "No obvious duplicate dependencies found"
        fi
    fi

    # Check for unused dependencies (requires devDependencies)
    if command -v depcheck &> /dev/null; then
        print_status "Running unused dependency check..."
        depcheck --json 2>/dev/null | jq -r '.dependencies[]? // .devDependencies[]?' 2>/dev/null | head -5 | while read dep; do
            if [ -n "$dep" ]; then
                print_warning "Potentially unused: $dep"
            fi
        done
    fi

    print_success "Bloat analysis complete"
}

# Main execution
print_header "🔍 PROJECT BLOAT ANALYSIS"

if ! command_exists node; then
    print_error "Node.js is not installed"
    exit 1
fi

comprehensive_bloat_check

print_header "📋 OPTIMIZATION RECOMMENDATIONS"
print_status "1. Run 'npm dedupe' to eliminate duplicate dependencies"
print_status "2. Consider 'npm prune --production' for production builds"
print_status "3. Review large dependencies for alternatives"
print_status "4. Use tree-shaking to eliminate unused code"
print_status "5. Enable compression for distribution packages"